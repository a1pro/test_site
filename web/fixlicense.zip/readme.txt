
  WHAT IS IT?

There are 2 aMember files to help you resolve license errors if aMember displays
it. 

  HOW TO USE THESE FILES?
1. Using your favorite FTP client, upload files
   amember/fixlicense.php
   amember/fixroot.php
   to amember/ folder. 
2. Using your browser, open URL: 
            http://www.yourdomain.com/amember/fixlicense.php
   Copy&paste new license code and press button. New license key will be
   stored into aMember database.
3. If you get other errors, like "Root URL doesn't match your license domain",
   open URL:
            http://www.yourdomain.com/amember/fixroot.php
   and enter new URLs for aMember Root URL and Secure Root URL.
4. Try to access aMember pages, specially signup page. If everything works,
   you have problems resolved. Using your FTP client, remove files
   fixlicense.php and fixroot.php from amember/ folder.

  WHAT TO DO IF IT DOESN'T HELP?
Please submit a trouble ticket to https://www.cgi-central.net/support/
Provide your FTP info and URL, along with short error description.
  